-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 �?08 �?04 �?18:39
-- 服务器版本: 5.5.40
-- PHP 版本: 5.6.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `blog`
--
CREATE DATABASE `blog` DEFAULT CHARACTER SET gbk COLLATE gbk_chinese_ci;
USE `blog`;

-- --------------------------------------------------------

--
-- 表的结构 `blog_article`
--

CREATE TABLE IF NOT EXISTS `blog_article` (
  `art_id` int(11) NOT NULL AUTO_INCREMENT,
  `art_title` varchar(100) DEFAULT NULL COMMENT '文章标题',
  `art_tag` varchar(100) DEFAULT NULL COMMENT '关键词',
  `art_description` varchar(255) DEFAULT NULL COMMENT '描述',
  `art_thumb` varchar(255) DEFAULT NULL COMMENT '缩略图',
  `art_content` text COMMENT '文章内容',
  `art_time` int(11) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `art_editor` varchar(50) DEFAULT NULL COMMENT '作者',
  `art_view` int(11) NOT NULL DEFAULT '0' COMMENT '查看次数',
  `cate_id` int(11) NOT NULL DEFAULT '0' COMMENT '分类id',
  PRIMARY KEY (`art_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk COMMENT='文章' AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `blog_article`
--

INSERT INTO `blog_article` (`art_id`, `art_title`, `art_tag`, `art_description`, `art_thumb`, `art_content`, `art_time`, `art_editor`, `art_view`, `cate_id`) VALUES
(1, 'wdsa', '', '', '', '<p>frdvc</p>', 1470190151, 'fds', 0, 1),
(2, 'lisa', 'rewqrdswe', '', 'uploads/20160803223640651.jpg', '<p>redfcxdasdc</p>', 1470192636, 'fesd', 0, 2),
(16, 'efsdfvxz', '', '', 'uploads/20160804090711883.jpg', '<p>sdafvxcx</p>', 1470272834, '', 0, 2),
(17, 'yhgvnvfmhjy', '', '', 'uploads/20160804090749861.jpg', '<p>vtydjcvfghjyyukfvhmjhnk</p>', 1470272881, 'lisa', 0, 2),
(18, 'dsxcv', '', '', 'uploads/20160804102459982.jpg', '<p>fdsgx</p>', 1470277500, '', 0, 2),
(3, '把握一颗珍珠的幸福', 'aDSAFSD', 'ASADFSAFDSF', '', '<p>&nbsp; 每想起这个故事，我就会联想起另一件事。有一段时间，我几乎每天傍晚都要到海边去散步，经常会看到一对头发斑白的老人，依偎在海边的一条长椅上看海。他俩总是静静地坐着，而面孔上则始终挂着一种祥和的微笑，宛如一尊神态安详的雕塑。</p><p>　　</p><p>　　<strong>有一天，我好奇地走到他俩近前，轻声地招呼道：“你们也喜欢看海吗？”</strong></p><p>　　</p><p>　　<span style="text-decoration: underline;">老人微笑着朝我点头示意，然后抬手指了指身旁的老伴。此时，我才发觉他原来是一位聋哑人，而他的妻子竟是一位双目失明的盲人。蓦然，我为自己刚才的失言而感到后悔。然而，在那两位老人的脸上却找不到一丝的不悦。相反，她竟用一种极其温和、坦诚的语气说：“是啊，我们老两口经常来‘看’海的——你一定会感到奇怪吧，其实只要彼此心灵之间不存在残疾，我们仍旧是两个正常的人。”</span></p><p>　　</p><p>　　两位老人的神情上没有流露出半点的自卑与遗憾，唯有幸福、自足的笑容在脉脉地向外流淌。我注视着眼前这一对恩爱可敬的老人，眼睛倏然湿润了……</p><p>　　</p><p>　　也许，就从那一刻起，我恍然从两位老人的笑容里寻求到了幸福的定义。真正的幸福，其实不是让我们冒着背负终生之憾的危险，刻意去剔除对方身上那一点点微不足道的瑕疵，而是要我们把握好自己手里的那一颗实实在在的珍珠，学会包容与珍惜，然后，才能从彼此心灵的和弦里感受到真正的幸福！</p><p><br/></p>', 1470216510, 'lisa', 0, 3),
(4, '人，其实是有魂的', 'aDSAFSD', 'ASADFSAFDSF', '', '<p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">承诺不是天上的白云，逍遥，飘逸；承诺不是绿波上的一朵浪花，轻盈，潇洒；承诺不是水面上的一叶浮萍，漂游不定；承诺不是夜幕中的一朵昙花，转瞬即逝。承诺如同珍珠，它的晶莹是蚌的痛苦的代价，也是蚌的荣耀；承诺如同金黄的谷粒，它的饱满是农民辛勤汗水的结晶，也是农民的希望；承诺如同蜂蜜，它的甘甜是蜜蜂勤劳的结晶，也是蜜蜂的骄傲 ；承诺如同流星，它的灿烂是陨石悲壮的付出，也是陨石的辉煌；承诺如同清晨绿草尖的露珠，晶亮而短暂。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">有力的话，好似枪膛里射出的一排子弹，使人的心灵受到猛烈的扣击，好似落在人身边的重磅炸弹，使人的头脑受到剧烈震动；亲切的话，有如平静的湖面吹来一阵轻微的风，使人的心头荡起一层感激的涟漪，有如春天的夜晚下了一场无声的细雨，使人的心里萌生了希望的绿芽。*、做不了大江大河，就做一条小小的溪流吧，做不了参天大树，就做一株小小的野草吧；做不了顶天立地的英雄，就做一个平凡的百姓吧。只要不停地奔流、生长、努力，也一样走过山高水远，也一样绿遍天涯，也一样活得光明磊落。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">我不是挺立高山的巨松，也不是屈身斗室的盆景，而是辽阔草原上的一棵小草——为壮丽的山河添上一笑。我不是都市激越的乐章，也不是乡野休闲的短笛，而是茫茫大漠中的一串驼铃——为勇敢的跋涉者解除寂寞。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">娇生惯养是培养低能儿的摇篮，高山寒土使苍松翠柏更加挺拔。司马迁受宫刑，文章字字玑珠；李后主被囚禁，词境为之一新；唐明皇沉迷声色，导致生灵涂炭；成克杰腐化堕落，终于自取灭亡。“生于忧患，死于安乐”，真是至理名言啊！<br/>&nbsp;</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">理解是生活的太阳，它将给人们带来无尽的温暖；理解是生活的发动机，它将给人们无穷的力量；理解是生活的美酒，它将给人们带来醉人的芳香。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">当你站在大海边时，大海的波涛也许是最美的；当你跋涉在戈壁大漠时，海市蜃楼也许是最美的；当你感到孤独时，亲情也许是最美的；当你沉浸赌场时，金钱也许是最美的。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">在茫茫宇宙中，个体生命显得多么渺小；在理想的生命境界的追求与严酷的现实生存环境的激烈冲突中，在与自然、与社会的抗衡中，个体的力量又多么不堪一击。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">但生命的进程所看重的并非结果而是过程。生命的全部意义就在于为人生所能达到的最高境界而追求、拼搏。</p><p><br/></p>', 1470216592, 'lisa', 0, 3),
(5, '白杨礼赞', '123', '12354463', '', '<p><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　那是力争上游的一种树，笔直的干，笔直的枝。它的干通常是丈把高，像加过人工似的，一丈以内，绝无旁枝。它所有的丫枝一律向上，而且紧紧靠拢，也像加过人工似的，成为一束，绝不旁逸斜出。它的宽大的叶子也是片片向上，几乎没有斜生的，更不用说倒垂了；它的皮光滑而有银色的晕圈，微微泛出淡青色。这是虽在北方风雪的压迫下却保持着倔强挺立的一种树。哪怕只有碗那样粗细，它却努力向上发展，高到丈许，两丈，参天耸立，不折不挠，对抗着西北风。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　这就是白杨树，西北极普通的一种树，然而决不是平凡的树！</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　它没有婆娑的姿态，没有屈曲盘旋的虬枝。也许你要说它不美，如果美是专指“婆娑”或“旁逸斜出”之类而言，那么，白杨树算不得树中的好女子；但是它伟岸，正直，朴质，严肃，也不缺乏温和，更不用提它的坚强不屈与挺拔，它是树中的伟丈夫！当你在积雪初融的高原上走过，看见平坦的大地上傲然挺立这么一株或一排白杨树，难道你就只觉得它只是树？难道你就不想到它的朴质，严肃，坚强不屈，至少也象征了北方的农民？难道你竟一点也不联想到，在敌后的广大土地上，到处有坚强不屈，就像这白杨树一样傲然挺立的守卫他们家乡的哨兵？难道你又不更远一点想到这样枝枝叶叶靠紧团结，力求上进的白杨树，宛然象征了今天在华北平原纵横决荡，用血写出新中国历史的那种精神和意志？</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　白杨不是平凡的树。它在西北极普遍，不被人重视，就跟北方的农民相似；它有极强的生命力，磨折不了，压迫不倒，也跟北方的农民相似。我赞美白杨树，就因为它不但象征了北方的农民，尤其象征了今天我们民族解放斗争中所不可缺的朴质，坚强，力求上进的精神。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　<span style="font-family: Arial, 宋体; line-height: 22.4px; text-indent: 28px; font-size: 20px; background-color: rgb(248, 248, 248);">让那些看不起民众，顽固的倒退的人们去赞美那贵族化的楠木，去鄙视这极常见，极易生长的白杨吧，我要高声赞美白杨树！</span></span></p>', 1470216643, 'lisa', 0, 3),
(6, '赞美是最悦耳的声音', '123', '12354463', '', '<p>　　在许多场合，适时得当的赞美常常会发挥它的神奇功效。林肯曾经说过：“人人都需要赞美，你我都不例外。”人人都渴望赞美，这是人们的共同心理。在人与人之间，无论是朋友之间、夫妻之间、师生之间、父母和子女之间，还是领导与下属之间，互相赞美是必不可少的。</p><p>　　</p><p>　　有一位著名的企业家，他给员工讲述了这样一件事情。在他还是一名见习服务员的时候，常常对生活不满意。特别是上班的第一天，他在杂货店里忙活了整整一天，累得筋疲力尽。他的帽子歪向了一边，工作服上沾满了点点污渍，双脚越来越疼。他感到疲倦和泄气，似乎觉得自己什么也干不好。好不容易为一位顾客列完了一张繁琐的账单，但是这位顾客的孩子们却三番五次地更换冰淇淋的订单，他这时候已经到了忍耐的极点。这时候，这一家人的父亲一边给他小费，一边笑着对他说：“干得不错，你对我们照顾得真是太周到了！”突然之间，他就感觉到疲倦消失得无影无踪了。后来，当经理问到他对头一天的工作感觉如何时，他回答说：“挺好！”那几句赞扬的话似乎把一切都改变了。</p><p>　　</p><p>　　忙碌的现代人在繁忙中逐渐丢掉了许多东西，包括短短的几句赞美之语。其实，赞扬就像是照在人们心灵上的阳光，没有阳光，我们就无法发育和成长。赞美不仅是一种悦耳的声音，更是一种力量，一种可以提升我们生活质量的强大力量。</p><p>　　</p><p>　　某饭店有个厨师可谓是声名远扬，他的拿手好菜是烤鸭，深受顾客的喜爱，他的老板更是倍加赏识，不过这个老板从未给过厨师任何鼓励，这使得厨师整天闷闷不乐。有一天，老板有朋友从远方来，在家设宴招待贵宾，点了数道菜，其中一道是老板最喜欢吃的烤鸭。当老板夹了一条鸭腿给客人时，却找不到另一条鸭腿，他便问身后的厨师：“另一条腿到哪里去了？”厨师说：“老板，我们家里养的鸭子都只有一条腿！”老板感到诧异，但碍于客人在场，不便问个究竟。</p><p><br/></p>', 1470216673, 'lisa', 0, 2),
(7, '六月花香 飘渺无迹', '123', '12354463', '', '<p><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　结庐荆棘之间，身外红尘；纵倚萧墙之下，不过云烟。潇潇冷雨，几缕茶烟，凄凉满眼。沧海一声叹，云烟枕墨眠，曾有的忧患恩怨都随了流尘，曾有的苍凉繁华都成了笑谈。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　清晨雨打窗棂，敲醒一枕残梦。孤身懒起，对镜束装，不觉微恙。窗外紫燕，出入呢喃，云天外，世事邀风皆远走，叹前路，迷迷茫茫雨也愁。年年月月，走过了，心凉了，由得心愿的竟无一点。所有一切都幻化成空，不消挥手，便散的飘渺无迹。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　闲步野径间，扶风吹雨，思绪缠绵。古道垂柳小桥，亭外萧疏竹院，烟雨苔痕间，淡成一帧水墨画卷。此时可以低吟，可以高歌，盛久不衰的，也只有心碎肠断罢了。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　这么多年，开心的时光不多，犹如一片云朵，身不由己于时间的心湖漂泊。书箴后的那些笔记，时常勾勒未来的美丽，眼睛后的那些期望，却常常滴落伤痛的雨，淋湿了岁月，沾满了衣襟。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　走过生命的坎坷离合，不知不觉，岁月竟已如此苍老。流年曾给过我一个美丽而又绝然的梦，如此的我，还要等多久，才能看到另一个结果。距离有多远？咫尺抑或是天涯……</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　眉锁年岁，遥相望，终至成殇。时光若留，又何苦悲景伤情，人事若老，何不将我，也带走。</span></p>', 1470216705, 'lisa', 0, 2),
(8, '张爱玲：天才梦', '123', '12354463', '', '<p>&nbsp;<span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">我是一个古怪的女孩，从小被视为天才，除了发展我的天才外别无生存的目标。然而，当童年的狂想逐渐褪色的时候，我发现我除了天才的梦之外一无所有——所有的只是天才的乖僻缺点。世人原谅瓦格涅的疏狂，可是他们不会原谅我。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　加上一点美国式的宣传，也许我会被誉为神童。我三岁时能背诵唐诗。我还记得摇摇摆摆地立在一个满清遗老的藤椅前朗吟&quot;商女不知亡国恨，隔江犹唱后庭花&quot;，眼看着他的泪珠滚下来。七岁时我写了第一部小说，一个家庭悲剧。遇到笔划复杂的字，我常常跑去问厨子怎样写。第二部小说是关于一个失恋自杀的女郎。我母亲批评说：如果她要自杀，她决不会从上海乘火车到西湖去自溺。可是我因为西湖诗意的背景。终于固执地保存了这一点。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　我仅有的课外读物是《西游记》与少量的童话，但我的思想并不为它们所束缚。八岁那年，我尝试过一篇类似乌托邦的小说，题名快乐村。快乐村人是一好战的高原民族，因克服苗人有功，蒙中国皇帝特许，免征赋税，并予自治权。所以快乐村是一个与外界隔绝的大家庭，自耕自织，保存着部落时代的活泼文化。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　我特地将半打练习簿缝在一起，预期一本洋洋大作，然而不久我就对这伟大的题材失去了兴趣。现在我仍旧保存着我所绘的插画多帧，介绍这种理想社会的服务，建筑，室内装修，包括图书馆，&quot;演武厅&quot;，巧克力店，屋顶花园。公共餐室是荷花池里一座凉亭。我不记得那里有没有电影院与社会主义——虽然缺少这两样文明产物，他们似乎也过得很好。</span></p>', 1470216744, 'lisa', 0, 2),
(9, '人生犹如一首歌，音调高低起伏，旋律抑扬顿挫', '123', '12354463', '', '<p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">在漆黑的夜晚，你要想到旭日东升的美好；在寒冷的冬季，你要想到千里冰封的壮丽；在汹涌的海边，你要想到乘风破浪的豪迈。人，决不能灰心于困难。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">我不是最美丽，但我可以最可爱；我不是最聪明，但我可以最勤奋；我不是最富有，但我可以最有情趣；我不是最健壮，但我可以最乐观。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">假如，你有一副动人的歌喉，但只会重复别人唱过的歌曲，我决不会把你赞许；假如，你有一副锐利的眼睛，但只会看到别人做事的是非，我决不会把你赞美；假如，你有一双健壮的脚板，但只会步踏别人走过的路，我决不会把你羡慕。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">如果说祖国是一艘远航的征船，我们就是那扬起的风帆；如果说青春是一盆不灭的炭火，我们就是那跳动的火焰。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">有理想的人说，生活像一杯蜂蜜，越品越甜；没有理想的人说，生活像一杯白开水，越喝越淡。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">以一种轻松平等的方式取代毕恭毕敬的心情，在呼朋引伴的称呼声中表现彼此友好的姿态，这不能不说是“朋友”一词的魅力所在。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">时间好比一部列车，它能承载我们驶向成功的未来；时间好比一位老人，它能帮助我们学到人生的真谛。人生犹如一次漫游，它能使你遇到许多新奇的事物；人生犹如一个顽童，它总是提出一些让你难以解答的问题。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">未经风雨交加的黑夜，哪能体会风和日丽的可爱；未经坎坷泥泞的艰难，哪能知道阳光大道的可贵，没有心血和汗水的付出，哪能尝到胜利成功的喜悦。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">其实人生也如四季：天真浪漫的童年是人生的春天，血气方刚的青年是人生的夏天，沉稳持重的中年是人生的秋天，蹒跚伛偻的老年是人生的冬天。但只要保持心灵的春天，生命将永远年轻。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">有勤，才有了孔子“韦编三绝”的佳话，也才有了孔子是世界文化史上大名人之一的美誉；有勤，才有了祖逖“闻鸡起舞”的美谈，也才有了他雄才大展北伐报国的伟业；有勤，才有了曹雪芹“披阅十载，增删五次”的壮举，也才有了世界文学史上的不朽名著《红楼梦》。</p><p><br/></p>', 1470216779, 'lisa', 0, 1),
(10, '花之笔记', '123', '12354463', '', '<p><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">&nbsp; &nbsp; &nbsp; 我喜欢那些美得扎实厚重的花，像百合、荷花、木棉，但我也喜欢那些美得让人发愁的花，特别是开在春天的，花瓣儿菲薄菲薄，眼看着便要薄得没有了的花，像桃花、杏花、李花、三色堇或波斯菊。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　花的颜色和线条总还比较&quot;实&quot;，花的香味却是一种介乎&quot;虚&quot;&quot;实&quot;之间的存在。有种花，像夜来香，香得又野又蛮，的确是&quot;花香欲破禅&quot;的那种香法，含笑和白兰的香是荤的，茉莉是素的，素得可以及茶的，水仙更美，一株水仙的倒影简直是一块明矾，可以把一池水都弄得干净澄澈。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　栀子花和木本株兰的香总是在日暖风和的时候才香得出来，所以也特别让人着急，因为不知道什么时候就没有了。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　树上的花是小说，有枝有干地攀在横交叉的结构上，俯下它漫天的华美，&quot;江边一树垂垂发&quot;、&quot;黄四娘家花满蹊，千朵万朵压枝低&quot;，那里面有多层次、多角度的说不尽的故事。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　草花是诗，由于矮，像是刚从土里蹦上来的，一种精粹的、鲜艳的、凝聚的、集中的美。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><a href="http://www.fzl25.com/" target="_blank" style="color: rgb(0, 0, 0); text-decoration: none; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; white-space: normal; background-color: rgb(248, 248, 248);"><span style="text-decoration:underline;">散文</span></a><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">是爬藤花，像九重萝、茶靡、紫藤、茑萝，乃至牵牛花和丝瓜花、扁豆花，都有一种走到哪里就开到哪里的浑洒。爬藤花看起来漫不经心，等开完了整个季节之后回头一看，倒也没有一篇是没有其章法的——无论是开在疏篱间的，泼撒在花架上的，哗哗地流下瓜棚的，或者不自惜的淌在坡地上的，乃至于调皮刁钻爬上老树，把枯木开得复活了似的……它们都各有其风格，真的，丝瓜花有它自己的文法，牵牛花有它自己的修辞。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　如果有什么花可以称之为舞台剧的，大概就是昙花了吧。它是一种彻底的时间艺术，在丝帷的开阖间即生而即死，它的每一秒钟都在&quot;动&quot;，它简直严格地遵守着古典戏剧的&quot;三一律&quot;——&quot;一时&quot;、&quot;一地&quot;、&quot;一事&quot;，使我感动的不是那一夕之间偶然白起来的花瓣，也不是那偶然香起来的细蕊，而是那几乎听得见的砰然有声的拆展的过程。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　文学批评如果用花来比喻，大概可以像仙人掌花，高大吓人，刺多花少，却大刺刺地像一声轰雷似的拔地而起——当然，好的仙人掌花还是漂亮得要命的。</span></p>', 1470216813, 'lisa', 0, 1),
(11, '经典有内涵的美文美句：岁月，是一首诗', '123', '12354463', '', '<p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">很多经典的美文美句，我们读过以后就遗忘了，当你想写点什么的时候，这些美文美句能丰富你文章的内涵，那就让我们一起来欣赏这些美文美句吧。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">1、 如果黑板就是浩淼的大海，那么，老师便是海上的水手。铃声响起那刻，你用教职工鞭作浆，划动那船只般泊在港口的课本 。课桌上，那难题堆放，犹如暗礁一样布列，你手势生动如一只飞翔的鸟，在讲台上挥一条优美弧线——船只穿过……天空飘不来一片云，犹如你亮堂堂的心，一派高远。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">2、 希望源于失望，奋起始于忧患，正如一位诗人所说：有饥饿感受的人一定消化好，有紧迫感受的人一定效率高，有危机感受的人一定进步快。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">3、 别在树下徘徊，别在雨中沉思，别在黑暗中落泪。向前看，不要回头，只要你勇于面对抬起头来，就会发现，分数的阴霾不过是短暂的雨季。向前看，还有一片明亮的天，不会使人感到彷徨。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">4、 柔和的阳光斜挂在苍松翠柏不凋的枝叶上，显得那么安静肃穆，绿色的草坪和白色的水泥道貌岸然上，脚步是那么轻起轻落，大家的心中却是那么的激动与思绪波涌。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">5、 生活的海洋并不像碧波涟漪的西子湖，随着时间的流动，它时而平静如镜，时而浪花飞溅，时而巨浪冲天……人们在经受大风大浪的考验之后，往往会变得更加坚强。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">6、 当你身临暖风拂面，鸟语花香，青山绿水，良田万顷的春景时，一定会陶醉其中；当你面对如金似银，硕果累累的金秋季节时，一定会欣喜不已。你可曾想过，那盎然的春色却是历经严寒洗礼后的英姿，那金秋的美景却是接受酷暑熔炼后的结晶。…………（何婷婷）</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">7、 倘若希望在金色的秋天收获果实，那么在寒意侵人的早春，就该卷起裤腿，去不懈地拓荒、播种、耕耘，直到收获的那一天。</p><p style="margin-top: 0px; margin-bottom: 12px; padding: 0px; text-indent: 2em; font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; white-space: normal; background-color: rgb(248, 248, 248);">8、 生活是蜿蜒在山中的小径，坎坷不平，沟崖在侧。摔倒了，要哭就哭吧，怕什么，不心装模作样！这是直率，不是软弱，因为哭一场并不影响赶路，反而能增添一份小心。山花烂漫，景色宜人，如果陶醉了，想笑就笑吧，不心故作矜持！这是直率，不是骄傲，因为笑一次并不影响赶路，反而能增添一份信心。</p><p><br/></p>', 1470216854, 'lisa', 0, 3),
(12, '在流年生活里，轻度时光', '123', '12354463', '', '<p>&nbsp; <span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">一个人映现一个世界；一颗心搏动一缕思绪。喜怒哀乐互相交织，悲欢离合彼此参合，阴晴阳缺轮流交替，人生都曾经一一饱尝过。有时，寂寞袭上心头，一时间惶惶不安，无所事事；有时，也许空虚侵入生活，百无聊奈，不知如何打发时光，怎度流年？有时，也许孤独叩击心门，心灵渴望一股真情，盼望与人相交，可以倾诉心事，共度阴暗时光。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　在时光里，一杯茶，一种人生。烧点开水，在悠闲里，你可以静观水气升腾，悠然自在，静听水声呢喃，响在耳边。一泡茶，一种观点，会苦上一阵子，但也会清香四溢，滞留齿间。品茶，浅尝人生，心静似止水。打发时间里，你何妨细细品尝温情的茶水，看水冒出气泡，观茶粒松散开来，也可详赏茶叶在翻腾，染绿清水。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　一杯甘浓的茶水进入口里，润滑有余香，舌底生津，心情舒畅。这时，一个人虽然孤身只影，却因为与茶相伴，一种安心从心底升起，静美时光持续不慌张，恒久不心乱。人生安详且时光深浓，光阴生动有力，日子生机勃勃。</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　</span><br/><span style="font-family: Arial, 宋体; font-size: 14px; line-height: 22.4px; text-indent: 28px; background-color: rgb(248, 248, 248);">　　如果有几个人，相聚一起，可以闲聊家长里短，趣谈家事、国事和天下事，畅想不同的人生、异同的追求和坚持的理想，可以讲逆境之人成才不易，也可以论信念支撑坚持。你们可以谈论“勤劳一日，可得一夜安眠；勤劳一生，可得幸福长眠。”几个人可以说艰难困苦铸就人才，不留退路才有出路，议论诸子百家，纵横天下焦点……人生不但抛走无奈而显得充实，生活撇开烦躁而变得宁静。</span></p>', 1470216886, 'lisa', 0, 3),
(15, 'efvdgtfh', '', '', 'uploads/20160803225904807.jpg', '<p>dwsfsdgvfvbcbgfxsdzS</p>', 1470236360, 'chenmeng', 0, 2),
(14, 'lisa', 'rewqrdswe', '', 'uploads/20160803223640651.jpg', '<p>redfcxdasdc</p>', 1470232471, 'fesd', 0, 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_category`
--

CREATE TABLE IF NOT EXISTS `blog_category` (
  `cate_id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(50) NOT NULL COMMENT '分类名称',
  `cate_title` varchar(255) NOT NULL COMMENT '分类说明',
  `cate_keywords` varchar(255) NOT NULL COMMENT '关键词',
  `cate_description` varchar(255) NOT NULL COMMENT '描述',
  `cate_view` int(10) NOT NULL DEFAULT '0' COMMENT '查看次数',
  `cate_order` tinyint(255) NOT NULL DEFAULT '0' COMMENT '排序',
  `cate_pid` int(11) NOT NULL DEFAULT '0' COMMENT '父级id',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- 转存表中的数据 `blog_category`
--

INSERT INTO `blog_category` (`cate_id`, `cate_name`, `cate_title`, `cate_keywords`, `cate_description`, `cate_view`, `cate_order`, `cate_pid`) VALUES
(2, '体育', '热爱体育事业，发扬体育精神', '', '', 0, 0, 0),
(3, '娱乐', '人人都有自己的娱乐圈', '', '', 0, 0, 0),
(25, 'safcdszv', '', '', '', 0, 0, 0),
(5, '热点新闻', '最热新闻，最好', '', '', 0, 0, 0),
(6, '军事新闻', '我没词了', '', '', 0, 12, 0),
(7, '体育彩票', '中奖率好高呀', '', '', 0, 0, 2),
(8, '体育赛事', '我们提供最新的体育赛事活动', '', '', 0, 0, 2),
(9, '音乐娱乐', '我喜欢听音乐', '', '', 0, 0, 3),
(24, 'sdfds', 'asdsfsdf', '', '', 0, 10, 0),
(17, 'dwsae', '', '', '', 0, 0, 16),
(12, '体育事业', '我是好人', '啊啊啊', 'cfxz', 0, 32, 2),
(19, 'qwd121323', 'sdxfdcx', '', '', 0, 0, 18);

-- --------------------------------------------------------

--
-- 表的结构 `blog_links`
--

CREATE TABLE IF NOT EXISTS `blog_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `link_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '链接',
  `link_order` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `blog_links`
--

INSERT INTO `blog_links` (`link_id`, `link_name`, `link_title`, `link_url`, `link_order`) VALUES
(1, '郑州师范学院', '国内最好的学', 'http://www.baidu.com', 1),
(2, '没啥说了', 'title是啥', 'http://www.baidu.com', 2),
(3, '极客学院', 'lisa真棒', 'http://www.baidu.com', 4);

-- --------------------------------------------------------

--
-- 表的结构 `blog_migrations`
--

CREATE TABLE IF NOT EXISTS `blog_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `blog_migrations`
--

INSERT INTO `blog_migrations` (`migration`, `batch`) VALUES
('2016_08_03_231522_create_links_table', 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_navs`
--

CREATE TABLE IF NOT EXISTS `blog_navs` (
  `nav_id` int(11) NOT NULL AUTO_INCREMENT,
  `nav_name` varchar(50) DEFAULT NULL COMMENT '名称',
  `nav_alias` varchar(50) DEFAULT NULL COMMENT '别名',
  `nav_url` varchar(255) DEFAULT NULL,
  `nav_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`nav_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='导航栏' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `blog_navs`
--

INSERT INTO `blog_navs` (`nav_id`, `nav_name`, `nav_alias`, `nav_url`, `nav_order`) VALUES
(2, '新闻', 'news', 'http://www.baidu.com', 2),
(3, '新闻', 'news', 'http://www.baidu.com', 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_user`
--

CREATE TABLE IF NOT EXISTS `blog_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL COMMENT '//用户名',
  `user_pass` varchar(255) DEFAULT NULL COMMENT '//密码',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `blog_user`
--

INSERT INTO `blog_user` (`user_id`, `user_name`, `user_pass`) VALUES
(1, 'lisa', 'eyJpdiI6IjdNVkVEZlFjVE5cL2EzVnRVSm9aUnJnPT0iLCJ2YWx1ZSI6ImVXWjYzWDFQZFEyb0c5RENyR0NqRXc9PSIsIm1hYyI6IjI1NWExODZhNTkxYjAyNmFiZmNjYmU4MDhkNGNhY2I2ZTI0NzY0ZWIzYjU5ZmY5Yzg4Y2Y5OTkzMjM5OWRkZGEifQ==');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
